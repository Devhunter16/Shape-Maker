
/**
*
* Author: Devin Hunter
* H6 Inc. Project
* Made with Open Graphics Library: A software interface to graphics hardware. OpenGL consists of over 250 different function calls which can be used to draw complex two and three-dimensional scenes.
*
*/

#pragma once

class Program {
public:
	void greetUser();

private:
	char decision;
	void promptUser();
	void runOpenGL();
};